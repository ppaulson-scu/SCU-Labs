# ifndef GEN_H
# define GEN_H

#include "Scope.h"

void generateGlobals(const Scope &scope);

#endif /* GEN_H */
