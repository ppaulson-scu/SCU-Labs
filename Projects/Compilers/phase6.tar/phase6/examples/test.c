int a;

int main(void){

	int *p;
	
	*p = 2;

}
