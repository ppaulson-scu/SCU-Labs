
int main(int b){

	int *p, x;
	char *s;

	s - p + x;
}
